<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('My Notes') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white dark:bg-gray-900">
                    @if ($notes->isEmpty())
                        <p class="text-gray-700 dark:text-gray-300">{{ __('No notes available. Create your first note!') }}</p>
                    @else
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead>
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        {{ __('Title') }}
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        {{ __('Content Preview') }}
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        {{ __('Actions') }}
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                                @foreach ($notes as $note)
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm font-medium text-gray-900 dark:text-gray-200">{{ $note->title }}</div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-500 dark:text-gray-400">{{ Str::limit(strip_tags($note->content), 50) }}</div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <a href="{{ route('notes.show', $note->id) }}" class="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300">
                                                {{ __('View') }}
                                            </a>
                                            <a href="#" onclick="shareNote('{{ $note->id }}')" class="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300 ml-4">
                                                {{ __('Share') }}
                                            </a>
                                            <a href="{{ route('notes.edit', $note->id) }}" class="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 ml-4">
                                                {{ __('Edit') }}
                                            </a>
                                            <form method="POST" action="{{ route('notes.destroy', $note->id) }}" class="inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300 ml-4">
                                                    {{ __('Delete') }}
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @endif
                    <div class="mt-6">
                        <a href="{{ route('notes.create') }}" class="bg-blue-500 text-white px-4 py-2 rounded-md">
                            {{ __('Create New Note') }}
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function shareNote(noteId) {
            // Implement share functionality here, e.g., opening a modal, sharing via social media, etc.
            alert('Share functionality for note ID: ' + noteId);
        }
    </script>
</x-app-layout>
