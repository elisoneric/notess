<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Note Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="font-bold text-xl mb-4"><?php echo e($note->title); ?></h3>
                    <div class="mb-4">
                    <p><?php echo e(Str::limit(strip_tags($note->content), 50, '...')); ?></p>

                    </div>
                    
                    <div class="flex justify-between">
                       <!-- Only show Edit option if the user owns the note -->
                            <a href="<?php echo e(route('notes.edit', $note)); ?>" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded">
                                <?php echo e(__('Edit Note')); ?>

                            </a>

                        <button onclick="shareNote('<?php echo e($note->id); ?>')" class="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded">
                            <?php echo e(__('Share Note')); ?>

                        </button>

                        <!-- Save as New button -->
                        <form action="<?php echo e(route('notes.saveAsNew', $note->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md">
                                <?php echo e(__('Save As New Note')); ?>

                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function shareNote(noteId) {
            const shareUrl = window.location.origin + '/notes/' + noteId + '/edit'; // Create a view-only URL
            navigator.clipboard.writeText(shareUrl)
                .then(() => {
                    alert('Note link copied to clipboard: ' + shareUrl);
                })
                .catch(err => {
                    alert('Failed to copy: ' + err);
                });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\notes-app\resources\views/notes/show.blade.php ENDPATH**/ ?>